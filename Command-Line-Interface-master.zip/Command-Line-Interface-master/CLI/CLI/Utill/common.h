#ifndef __COMMON_H__
#define __COMMON_H__

int atoh(uint8_t *s);

void Delay_us(uint32_t time);

#endif /* __COMMON_H__ */
